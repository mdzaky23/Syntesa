<?php

return [
    'name' => 'Pengajuan'
];
