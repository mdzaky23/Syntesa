@include('pengajuan::layouts.head')
@include('pengajuan::layouts.navbar')
@include('pengajuan::layouts.sidebar')
   

@yield('content')
 
@include('pengajuan::layouts.footer')
   