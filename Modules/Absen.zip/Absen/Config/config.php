<?php

return [
    'name' => 'Absen'
];
