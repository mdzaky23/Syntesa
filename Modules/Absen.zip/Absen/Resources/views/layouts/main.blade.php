@include('absen::layouts.head')
@include('absen::layouts.navbar')
@include('absen::layouts.sidebar')

@yield('content')

@include('absen::layouts.footer')


